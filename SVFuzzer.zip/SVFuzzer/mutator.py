import random


class Mutator:
    def mutate(self, s: str):
        """
        randomly stack mutators 1-5 times.

        :param s: the input string
        :return s: the mutated string
        """
        return s

    @staticmethod
    def insert_random_character(s: str) -> str:
        """
        insert a character from ASCII printable characters and the extended ASCII codes at a random position

        :param s: the input string
        :return s: the mutated string
        """
        return s

    @staticmethod
    def remove_random_character(s: str) -> str:
        """
        remove a random character from the string

        :param s: the input string
        :return s: the mutated string
        """
        return s

    @staticmethod
    def swap_characters(s: str) -> str:
        """
        randomly swap two characters of the string

        :param s: the input string
        :return s: the mutated string
        """
        return s

    @staticmethod
    def scramble_characters(s: str) -> str:
        """
        select a random number of characters from the string (which may not be contiguous)
        and randomly shuffle their values

        :param s: the input string
        :return s: the mutated string
        """
        return s

    @staticmethod
    def invert_characters(s: str) -> str:
        """
        select a random number of contiguous characters from the string and reverse their order

        :param s: the input string
        :return s: the mutated string
        """
        return s


